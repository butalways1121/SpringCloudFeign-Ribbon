package com.SpringCloudFeignConsumer2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


//提供一个接口然后打印信息即可
@RestController
public class ConsumerController {

	@RequestMapping("/helloworld")
	public String index(@RequestParam String name) {
        return name+",Hello World";
    }
}
