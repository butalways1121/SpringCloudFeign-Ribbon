package com.SpringCloudRibbonConsumer.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用于转发请求
 * @author 20180877
 *
 */
@RestController
public class ConsumerController {
	
	@RequestMapping("/hello")
	public String index(@RequestParam String name) {
		return name+",Hello World!这是另一个服务！";
	}
}
