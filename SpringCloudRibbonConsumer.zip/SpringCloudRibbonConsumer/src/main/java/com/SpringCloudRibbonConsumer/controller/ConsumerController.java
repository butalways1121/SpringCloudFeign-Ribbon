package com.SpringCloudRibbonConsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.SpringCloudRibbonConsumer.remote.HelloRemote;

//需要定义转发的服务，这里使用RestTemplate来进行调用，调用另外一个服务的名称。
@RestController
public class ConsumerController {
	
	@Autowired
	RestTemplate restTemplate;
	
	//Ribbon实现负载均衡
	@RequestMapping("/hello")
    public String hello() {
    	//进行远程调用
        return restTemplate.getForObject("http://springcloud-ribbon-consumer2/hello/?name=butalways", String.class);
    }
	
	//提供一个新的接口供外部调用，Ribbon结合Feign
	@Autowired
    HelloRemote helloRemote;
	
    @RequestMapping("/hello/{name}")
    public String index(@PathVariable("name") String name) {
    	System.out.println("接受到请求参数:"+name+",进行转发到其他服务!");
        return helloRemote.hello(name);
    }
}
