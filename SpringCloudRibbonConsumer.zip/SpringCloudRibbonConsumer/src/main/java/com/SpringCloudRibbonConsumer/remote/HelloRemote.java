package com.SpringCloudRibbonConsumer.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 实现feign远程调用
 * @author 20180877
 *
 */
@FeignClient(name= "springcloud-ribbon-consumer2") 
public interface HelloRemote {

	@RequestMapping(value = "/hello")
    public String hello(@RequestParam(value = "name") String name);
}
