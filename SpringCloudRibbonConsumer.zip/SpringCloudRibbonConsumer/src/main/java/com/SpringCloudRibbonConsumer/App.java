package com.SpringCloudRibbonConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * Hello world!
 *
 */
//使用Ribbon实现负载均衡，只需要在启动类中实例化RestTemplate，通过@LoadBalanced注解开启均衡负载能力.。
@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
//@EnableFeignClients启用feign进行远程调用
public class App 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(App.class, args);
        System.out.println( "ribbon第一个消费者服务启动..." );
    }
    
    @Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
