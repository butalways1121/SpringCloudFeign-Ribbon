package com.SpringCloudFeignConsumer.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//转发类代码
@FeignClient(name = "springcloud-feign-consumer2")
public interface HelloRemote {
	
	@RequestMapping(value = "/helloworld")
	public String hello(@RequestParam(value = "name") String name);
	
}
