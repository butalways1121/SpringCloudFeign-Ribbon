package com.SpringCloudFeignConsumer.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * 转发类代码,定义需要转发的服务
 */
@FeignClient(name = "springcloud-feign-consumer2")
public interface HelloRemote {
	
	@RequestMapping(value = "/helloworld")
	//@RequestParam主要用于将请求参数区域的数据映射到控制层方法的参数上,即获取前端参数
	public String hello(@RequestParam(value = "name") String name);
	
}
