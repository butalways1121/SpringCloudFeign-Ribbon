package com.SpringCloudFeignConsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpringCloudFeignConsumer.remote.HelloRemote;

//提供一个入口供外部调用，调用HelloRemote中的方法进行转发
@RestController
public class ConsumerController {

	@Autowired
	HelloRemote helloRemote;
	
	@RequestMapping("/hello/{name}")
    public String index(@PathVariable("name") String name) {
    	System.out.println("接受到请求参数:"+name+",进行转发到其他服务");
        return helloRemote.hello(name);
    }
}
